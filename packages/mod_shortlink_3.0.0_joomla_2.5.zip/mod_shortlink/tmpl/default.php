<?php defined('_JEXEC') or die('Restricted access'); // no direct access ?>
<?php echo 'DEFAULT TEMPLATE IS NOT USED'; ?>
