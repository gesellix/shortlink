DROP TABLE `#__shortlink`;
